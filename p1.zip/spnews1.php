﻿<?php include"includes/header.php" ?> `
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>SGH-MADINAH PARTICIPATION IN UROLOGY CLUB MEETING </strong></h4><br>
        <div class="col-md-12" style="
                                      text-align: center;">



            <img src="files/images/news1.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>
        <div class="col-md-9" style="padding-top:25px;"></div></div>

    <div class="col-md-12">
        <p class="text-justify">
            Urologists at Saudi German Hospital- Madinah participated in the scientific conference which was organized under the auspices of Urology Club. Urologists at Al-Madinah Al-Mounawarah hospitals were invited to participate in the monthly urological conference. This conference reviewed the new advances in urological technology.The conference was managed by President of Urology Club in Al Madinah Dr. Emad Salama. He highly praised the outstanding urological services provided by all hospitals in Al-Madinah .He also thanked Saudi German hospital, represented by urological department , for sponsoring the conference. Consultant Urologist and Head of Urology Department Dr.Adel Farhat discussed a series of clinical complicated cases which have been treated at the hospital. Advanced devices and skills were used to treat these cases .These cases were presented to exchange views and experiences and to discuss the latest technologies used in the hospital.
        </p>

    </div>





</div>


<div class="col-md-12">
    <br><br>
</div>



<?php include"includes/footer.php" ?>

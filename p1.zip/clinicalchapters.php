﻿
<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Quality & Safety </a>
        <a href="cebahichapters" class="list-group-item list-group-item-action">Policies & procedures</a>
        <a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Procedures & Guidelines</a>
        <a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
        <a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
        <a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-3" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <!--<div class="btn-group" role="group">
<a href="clinicalprocedureguideline" class="btn btn-primary">Introduction</a>
</div>-->
                <div class="btn-group" role="group">
                    <a href="clinicalchapters" class="btn btn-primary">CPGLs</a>
                </div>

            </div>
        </div>

        <br> <br> <br>


        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"  >
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            IM
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput" onkeyup="search('myInput','myUL','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>

                        <ul id="myUL" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/IM/DKA.PDF" class="list-group-item "> Guidelines for the Diagnosis and Management of Diabetic Ketoacidosis in adult patients
                                        </a></li>
                                </div>
                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/IM/hypoglycemia.doc_for_reencodeing.PDF" class="list-group-item "> Guidelines for the Diagnosis and Management of Hypoglycemia

                                        </a></li>
                                </div>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTow">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTow" aria-expanded="false" aria-controls="collapseTow">
                            OBGYN
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseTow" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingTow">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput2" onkeyup="search('myInput2','myUL2','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL2" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/OBGYN/1_Guidelines_for_CS_2017.doc_edited_last.PDF" class="list-group-item ">Guidelines for Cesarean Delivery


                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/OBGYN/2_Normal_vaginal_delivary__2017.PDF" class="list-group-item "> Guidelines for Management of Normal Labor and Delivery
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/OBGYN/3_Perineal_trauma_-_OBGYNE.PDF" class="list-group-item "> Perineal Trauma
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/OBGYN/4_Operative_vaginal_delivery_2017_.PDF" class="list-group-item "> Operative Vaginal Delivery

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/OBGYN/hypoglycemia.doc_for_reencodeing.PDF" class="list-group-item "> Guidelines for the Diagnosis and Management of Hypoglycemia
                                        </a></li>
                                </div>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingThree">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            PEDIATRIC
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingThree">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput3" onkeyup="search('myInput3','myUL3','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL3" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/1.diabetic_Ketoacidosis_in_children.PDF" class="list-group-item "> Management of Diabetic Ketoacidosis in Children



                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/2.Pedia002_Status_Epilepticus_for_Children.PDF" class="list-group-item "> Status Epilepticus for Children

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/3.Pedia_003_children_asthma_.PDF" class="list-group-item "> Assessment of Bronchial Asthma Severity for Pediatric Patients
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/4_pedia_004_pediatric_triage.PDF" class="list-group-item "> Pediatric Triage

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/5.management_of_Shock.doc_-_finalized.PDF" class="list-group-item ">Management of Shock
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/6._Brain_edema__pedia_006.doc_-_finalised.PDF" class="list-group-item ">Management of Brain Edema for Children

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/7.pedia_GE__in_Children.PDF" class="list-group-item ">Guideline for Management of pediatric gastroenteritis
                                        </a></li>
                                </div>
                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/PEDIATRIC/8.pedia008_hypertensive_crisis_Children.PDF" class="list-group-item ">Guideline for Management of Hypertensive Crisis for Pediatric Patient

                                        </a></li>
                                </div>
                            </div>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingFour">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            ICU-CCU
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseFour" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingFour">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput4" onkeyup="search('myInput4','myUL4','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL4" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/0010_ICU_protocol-pulmonary_embolism_1.PDF" class="list-group-item ">Pulmonary Embolism
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/0011_ICU_NUTRITION_protocol_1.PDF" class="list-group-item ">Nutrition Protocol

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/0012_ICU_protocol_Electrolytes_Replacement_.PDF" class="list-group-item ">Electrolyte Replacement
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/0013_ICU_protocol__SEDATION_PROTOCOL.PDF" class="list-group-item ">Sedation Protocol
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/001ICU_protocols-_hyponatremia_.PDF" class="list-group-item ">Hyponatremia

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/002_ICU_protocols-_hypernatremia_.PDF" class="list-group-item ">Hypernatremia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/003_ICU_protocols-_hypokalemia_.PDF" class="list-group-item ">Hypokalemia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/004_ICU_protocols-_hyperkalemia_.PDF" class="list-group-item ">Hyperkalemia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/005ICU_protocols-_hypercalcemia_.PDF" class="list-group-item ">Hypercalcemia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/006_ICU_protocols-_hypomagnesaemia_.PDF" class="list-group-item "> Hypomagnesaemia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/007_ICU_protocols-_hyperphosphatemia_.PDF" class="list-group-item ">Hypophosphatemia

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/008_ICU_protocol_acid-base.PDF" class="list-group-item "> Acid – base protocol

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/009_GUIDELINES_FOR_ALBUMIN_USE_IN_ADULTS_.PDF" class="list-group-item ">Guidelines for albumin use in adults

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0014_Septic_Shock.PDF" class="list-group-item ">Management of Severe Sepsis and Septic Shock


                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0015_Status_Epilepticus.PDF" class="list-group-item ">Status Epilepticus


                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0016_mechanical_ventilator_weaning_protocol.PDF" class="list-group-item ">Mechanical Ventilator Weaning Protocol

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0017_brain_trauma_injury.PDF" class="list-group-item ">Management of Traumatic Brain Injury Cases from Emergency to Intensive Care

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0018_candida_infection.PDF" class="list-group-item ">Management Protocol for Systematic Candida Infection in NON- Neutropenic


                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0019_insulin_infusion_protocol.PDF" class="list-group-item "> Insulin Infusion Protocol

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/ICU/ICU_protocol_0020_IV_Heparin_Protocol.PDF" class="list-group-item "> IV Heparin Protocol
                                        </a></li>
                                </div>
                            </div>




                        </ul>
                    </div>
                </div>
            </div>


            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingFive">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            NICU
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseFive" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingFive">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput5" onkeyup="search('myInput5','myUL5','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL5" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Age_of_Viability.PDF" class="list-group-item ">Age of Viability
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Apnea_newborn.PDF" class="list-group-item ">Apnea For Newborn
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Breastmilk_collection.PDF" class="list-group-item "> Breastmilk Collection and Handling
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Bronchopulmonary_-_Dr._Rashad.PDF" class="list-group-item "> Bronchopulmonary Dysplasia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/cranial.PDF" class="list-group-item ">Cranial Ultrasound Scans in Newborns
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/exchange_trasfusion.PDF" class="list-group-item ">Exchange Trasfusion
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Feeding_Protocol.PDF" class="list-group-item ">Feeding Protocol
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Guidelines_for_newborns_with_disorder_of_sex_dev.(DSD).PDF" class="list-group-item ">Guidelines for Newborns with Disorder of Sex
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Hearing_Screening_dec_27_2016.PDF" class="list-group-item ">Hearing_Screening Guidelines
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/hyperbilinima.PDF" class="list-group-item ">Guidelines for Treatment of Hyperbilinima
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Hypothermic_for_Newborns.PDF" class="list-group-item ">Hypothermic for Newborns
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Management_of_Extravasation_the_Nicu.PDF" class="list-group-item ">Management of Extravasation the NICU
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Management_of_Neonatal_Hypotension.PDF" class="list-group-item ">Management of Neonatal Hypotension
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Management_of_PDA.PDF" class="list-group-item ">Management of PDA
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/NEC.PDF" class="list-group-item ">Necrotizing Enterocolitis
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Neonates.PDF" class="list-group-item ">Nitric Oxide Policy
                                        </a></li>
                                </div>
                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Neontal_HYpoglycemia.PDF" class="list-group-item ">Neontal Hypoglycemia
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/NICU_Cpgl_-1.PDF" class="list-group-item ">Guidlines of Managment of Neonatal Seizures

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/nitric_Oxide_POlicy.PDF" class="list-group-item ">Nitric Oxide POlicy

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/OSTEOPENIA_OF_PREMATURITY.doc__24.PDF" class="list-group-item ">Osteopenia of Prematurity
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Pain_assessment_and_management_in_neonates.-_ok.PDF" class="list-group-item ">Pain Assessment and Management in neonates
                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Pulmonary_Hypertension.PDF" class="list-group-item ">Pulmonary Hypertension

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Retinoplaty.PDF" class="list-group-item ">Retinopathy of Prematurity

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Summary_and_Recommendations_of_Group_B_Streptococcal.___-__23.PDF" class="list-group-item ">Summary and Recommendations of Group B Streptococcal

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Surfactant_therapy_and_administration.PDF" class="list-group-item ">Surfactant Therapy and Administration

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Total_Parental_Nutrition.PDF" class="list-group-item ">Total Parental Nutrition

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Transfusion_22_NICU.PDF" class="list-group-item ">Blood Products Transfusion in NICU

                                        </a></li>
                                </div>
                            </div>
                            <div class="row myli">
                                <div class="col-md-10">
                                    <li><a href="files/doc/NICU/Insertion_and_management.PDF" class="list-group-item ">Insertion and Management of Central Venous Catheter

                                        </a></li>
                                </div>
                            </div>

                        </ul>
                    </div>
                </div>
            </div>



        </div>
    </div>
</div>
<BR>
    <BR>
        <BR>
            <BR>


                <div class="col-md-12">
                    <br><br>
                </div>


                <?php include"includes/footer.php" ?>

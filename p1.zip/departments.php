﻿<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9">
    <div class="row">

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0eent.v1.jpg" alt="Card image cap">
                <div class="card-body">
                    <a href="entdepartments" class="list-group-item ">
                        <h4 class="card-title">ENT</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0nuro.v1.png" alt="Card image cap" />
                <div class="card-body">
                    <a href="neurodepartments" class="list-group-item ">
                        <h4 class="card-title">Neurology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0nurosur.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="nurosurdepartments" class="list-group-item ">
                        <h4 class="card-title">Neurosurgery</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-12" style="padding-top:25px"></div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0onco.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="oncodepartments" class="list-group-item ">
                        <h4 class="card-title">Oncology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0dental.v1.png" alt="Card image cap" />
                <div class="card-body">
                    <a href="dentdepartments" class="list-group-item ">
                        <h4 class="card-title">Dentistry</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0optho.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="opthdepartments" class="list-group-item ">
                        <h4 class="card-title">Ophthalmology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0plastic.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="pldepartments" class="list-group-item ">
                        <h4 class="card-title"> Plastic Surgery</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0ortho.v1.png" alt="Card image cap" />
                <div class="card-body">
                    <a href="orthodepartments" class="list-group-item ">
                        <h4 class="card-title">Orthopedic </h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0ob.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="obdepartments" class="list-group-item ">
                        <h4 class="card-title">Obstetrics & Gynecology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0derma.v1.jpg" alt="Card image cap">
                <div class="card-body">
                    <a href="dermadepartments" class="list-group-item ">
                        <h4 class="card-title"> Dermatology</h4>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0pedia.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="pediadepartments" class="list-group-item ">
                        <h4 class="card-title">Pediratic</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/surgcardio.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="surgcardepartments" class="list-group-item ">
                        <h4 class="card-title"></h4>Cardiothoracic</a>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0cardio.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="cardiodepartments" class="list-group-item ">
                        <h4 class="card-title"> Cardiology</h4>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0urol.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="urodepartments" class="list-group-item ">
                        <h4 class="card-title"> Urology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0surg.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="surgdepartments" class="list-group-item ">
                        <h4 class="card-title"> General & Vascular Surgery</h4>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/0nephro.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="nephrodepartments" class="list-group-item ">
                        <h4 class="card-title"> Nephrology</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/chest.png" alt="Card image cap">
                <div class="card-body">
                    <a href="chestdepartments" class="list-group-item ">
                        <h4 class="card-title">Chest Diseases</h4>
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/im.png" alt="Card image cap">
                <div class="card-body">
                    <a href="imdepartments" class="list-group-item ">
                        <h4 class="card-title">Internal Medicine</h4>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-4" style="padding-top:25px">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/rheum.v1.png" alt="Card image cap">
                <div class="card-body">
                    <a href="rhedepartments" class="list-group-item ">
                        <h4 class="card-title">Rheumatology</h4>
                    </a>
                </div>
            </div>
        </div>


    </div>

</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
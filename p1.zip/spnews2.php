﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>INFECTION CONTROL DURING HAJJ SEASON</strong></h4><br>


        <div class="col-md-12" style="
                                      text-align: center;">



            <img src="files/images/news2.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"></div>


            <div class="col-md-12">
                <p class="text-justify">
                    In cooperation with Al Madinah Regional Municipality SGH-Madinah organized health campaign to define infection control during Hajj season SGH-Madinah in cooperation with Al Madinah Regional Municipality organized an awareness campaign to define infection control during Hajj season, where the campaign was held at the headquarters of AlMadinah Regional Municipality, the campaign included a free checkup for Al Madinah Regional Municipality staff and auditors, medical consultations on the infection and chronic diseases , explaining the symptoms and how to deal with these symptoms in case of observation on the infected.These initiatives are based on the provision of community services within the framework of the social responsibility programs in the hospital, which aims at continuous communication with various sectors in the region.
                </p>

            

        </div>
    </div>
</div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
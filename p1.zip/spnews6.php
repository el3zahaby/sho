﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>VISIT OF KATSINA STATE GOVERNOR FROM NIGERIA TO SGH MADINAH</strong></h4><br>
        <div class="col-md-12" style="  text-align: center;">

            <img src="files/images/news6.JPG"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"></div>

            <div class="col-md-12">
                <p class="text-justify">
                    Visit of katsina state  governor  from Nigeria to SGH Madinah upon our invitation to him during our last visit to Nigeria. He met Dr.Ramiz CEO for discussing our cooperation in health care sector . He had a tour in the hospital . We aimed through this visit to enhance our business with them . we will have a MOU  agreement with them . on 20 June 2017.
                </p>

            </div>


        </div>
    </div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
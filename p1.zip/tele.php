<?php include"includes/header.php" ?>


<div class="container">
    <div class="row">
        <div class="col-sm-6">

            <table class="table">
                <thead >
                    <tr>

                        <th>C.E.O-OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR RAMEG AWADY (CEO)</td>
                        <td>5001/5002</td>


                    </tr>
                    <tr>
                        <td>MS.SHERILYN ESPIRITU</td>
                        <td>6608</td>

                    </tr>
                    <tr>
                        <td>MR.ASRAF MOHMMED</td>
                        <td>5860</td>
                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>VICE PRESIDENT OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR.KHALID BATTERJE</td>
                        <td>5077/5076</td>

                    </tr>
                    <tr>

                        <td>DUTY MANAGER</td>
                        <td>5066</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>EXE-MED-DIR OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MAHMOUD ASAAD</td>
                        <td>5477</td>

                    </tr>
                    <tr>

                        <td>SEC</td>
                        <td>5071/5066</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>ENT DEPT</th>
                        <th>5221</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR AHAMED SAPTHY</td>
                        <td>5207</td>

                    </tr>
                    <tr>

                        <td>DR AHMED ADLY</td>
                        <td>5206</td>

                    </tr>
                    <tr>
                        <td>DR KHALID SAIF</td>
                        <td>5208</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>CARDIOTHORACIC</th>
                        <th>5113</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR ASRAF FAWZI	</td>
                        <td>5126</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>CARDIOLOGY</th>
                        <th>5113</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR.HALIM MOHD ABDULLAH</td>
                        <td>5128</td>

                    </tr>

                    <tr>

                        <td>DR.MOHMMED ZINHOM</td>
                        <td>5127</td>

                    </tr>

                    <tr>

                        <td>DR.MOHMMED OMER</td>
                        <td>1583</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>OPTHALMOLOGY</th>
                        <th>5113</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR HISHAM KATAN</td>
                        <td>5138/5139</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>DERMATOLOGY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR HONEY AZIZ</td>
                        <td>5375</td>

                    </tr>
                    <tr>

                        <td>DR DALIA YOSRY </td>
                        <td>5377</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>OB/GYNE</th>
                        <th>5283</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR HAMED SHALBY</td>
                        <td>5284</td>

                    </tr>
                    <tr>

                        <td>DR AEYDA KASEM</td>
                        <td>5290</td>

                    </tr>
                    <tr>
                        <td>DR BASEM TAALAT</td>
                        <td>5286</td>
                    </tr>
                    <tr>
                        <td>DR ISLAM MHAMMED</td>
                        <td>5288</td>
                    </tr>
                    <tr>
                        <td>DR NASWAN FRAG </td>
                        <td>5291</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>UROLOGY</th>
                        <th>515</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR ADIL FARHAT</td>
                        <td>5157/5156</td>

                    </tr>
                    <tr>

                        <td>DR AHMED AL-DESOKI</td>
                        <td>5158</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>DENTAL</th>
                        <th>5261</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MUSTAFA SHABAN </td>
                        <td>5277</td>

                    </tr>
                    <tr>

                        <td>DR NAYARA ATEF SAYED </td>
                        <td>5269</td>

                    </tr>
                    <tr>

                        <td>DR SHEMA JALA</td>
                        <td>5278</td>

                    </tr>
                    <tr>
                        <td>DR ABEER MANMKANY</td>
                        <td>5278</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>PLASTIC SURGERY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR YOSEF ALBOOQ</td>
                        <td>5378</td>

                    </tr>
                    <tr>

                        <td>DR AHAMED RASAD</td>
                        <td>5379</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>PICU</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>NURSE STATION</td>
                        <td>5503/5505</td>

                    </tr>
                    <tr>

                        <td>NEW BORN ISOLATION</td>
                        <td>1609</td>

                    </tr>
                    <tr>
                        <td>SPECIAL CARE</td>
                        <td>1608</td>
                    </tr>

                    <tr>
                        <td>PICU GF</td>
                        <td>5503/5504</td>
                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>HEAMODIALASIS	</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>RECEPTION</td>
                        <td>1265/1266</td>

                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>ANESTHESIA CLINIC</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR.WALID CHAD</td>
                        <td>1557/1556</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>EMERGENCY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>NURSE STATION</td>
                        <td>5543/5545</td>

                    </tr>
                    <tr>

                        <td>RECEPTION</td>
                        <td>5537</td>

                    </tr>
                    <tr>
                        <td>ER-WARD(SECRETARY)</td>
                        <td>5543</td>
                    </tr>
                    <tr>
                        <td>ER-DR.ROOM</td>
                        <td>5544</td>
                    </tr>
                    <tr>
                        <td>ER-OR RECOVERY ROOM(M)</td>
                        <td>5505/5506</td>
                    </tr>
                    <tr>
                        <td>ER-OR RECOVERY ROOM(F)</td>
                        <td>5500/5501</td>
                    </tr>
                </tbody>

                <thead >
                    <tr>

                        <th>ENDOSECOPY UNIT</th>
                        <th>5524/5523</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR AMRO ABO ALFOTOOH</td>
                        <td>5246</td>

                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>MAINTENANCE</th>
                        <th>6111/6106</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td> MR YARAN  KHAN</td>
                        <td>6800/6112 </td>

                    </tr>
                    <tr>

                        <td>MR SAJAD SHA</td>
                        <td>6444</td>

                    </tr>
                    <tr>
                        <td>MR  ABDUL NABY SAYED</td>
                        <td>6445</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>MEDICAL RECORD</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR.SAMIY ALKRAD</td>
                        <td>6890/6591</td>

                    </tr>
                    <tr>

                        <td>OPERATOR</td>
                        <td>6350/6351</td>

                    </tr>
                    <tr>
                        <td>MRD(G.FLOOR)</td>
                        <td>5013</td>
                    </tr>

                    <tr>
                        <td>MRD(OR)DICTATION</td>
                        <td>1555</td>
                    </tr>
                </tbody>

                <thead >
                    <tr>

                        <th>KITCHEN</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR JAMIL(CHEF)</td>
                        <td>6845</td>

                    </tr>
                    <tr>

                        <td>MR.ANOWER REZA (STORE)</td>
                        <td>6549</td>

                    </tr>
                    <tr>
                        <td>BAKERY</td>
                        <td>6546</td>
                    </tr>

                    <tr>
                        <td>SERVICE AREA</td>
                        <td>6544/6542</td>
                    </tr>
                    <tr>
                        <td>DIETITION</td>
                        <td>6541</td>
                    </tr>
                    <tr>
                        <td>(SER AREA)</td>
                        <td>6540</td>
                    </tr>
                    <tr>
                        <td>FOOD DISTRIBUTION</td>
                        <td>6542/6543</td>
                    </tr>
                </tbody>

                <thead >
                    <tr>

                        <th>COMPUTER</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR SHAUKAT KHAN</td>
                        <td>6858/6363</td>

                    </tr>
                    <tr>

                        <td>MR.MOHAMED ADIL</td>
                        <td>6361</td>

                    </tr>
                    <tr>
                        <td>MR RIZWAN SHAIKH</td>
                        <td>6362</td>
                    </tr>
                    <tr>
                        <td>MR IMRAN NOOR</td>
                        <td>6357</td>
                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>PERSONNEL</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR KHALED SADI</td>
                        <td>6885</td>

                    </tr>
                    <tr>

                        <td>MR.SALAH ALAMEEN</td>
                        <td>6500</td>

                    </tr>
                    <tr>
                        <td>MR KASIM/MS SORRYA</td>
                        <td>6389</td>
                    </tr>
                    <tr>

                        <td>MR IRSHAD AHMED</td>
                        <td>6387</td>

                    </tr>
                    <tr>

                        <td>MS TABASSUM TABISH </td>
                        <td>6396</td>

                    </tr>
                    <tr>
                        <td>SECRETARY</td>
                        <td>6801</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>HUMEN RESOURCE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR MUHAMMED RIZWAN</td>
                        <td>6390</td>

                    </tr>
                    <tr>

                        <td>MR SALMAN NOOR</td>
                        <td>6584/6365</td>

                    </tr>
                    <tr>
                        <td>MR SALMAN NOOR</td>
                        <td>6582</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>A/C-RECEIVABLE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MUHAMMAD AMJAD</td>
                        <td>6524/6373</td>

                    </tr>
                    <tr>

                        <td>DR JAWAD/MR AMIR</td>
                        <td>6370/6872</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>FINANCE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR RANA KHURRAM</td>
                        <td>6516</td>

                    </tr>
                    <tr>

                        <td>MR KHALID LATEF</td>
                        <td>6802/6503</td>

                    </tr>
                    <tr>
                        <td>MR MUHAMMAD ASIF </td>
                        <td>6506</td>
                    </tr>
                    <tr>

                        <td>MR MOHIB ULLAH SAFIULLA</td>
                        <td>6518</td>

                    </tr>
                    <tr>

                        <td>MR ALIM ALLAH</td>
                        <td>6523</td>

                    </tr>
                    <tr>
                        <td>MR MUHAMMAD ATIF</td>
                        <td>6507</td>
                    </tr>
                    <tr>
                        <td>DR QAZI ARIF</td>
                        <td>6517</td>
                    </tr>
                    <tr>
                        <td>MR MRMUHAMMAD USMAN (GIA)</td>
                        <td>3341</td>
                    </tr>

                    <tr>

                        <td>MR ATTA ABOUELATA</td>
                        <td>5008</td>

                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>COMPANY APROVEL</th>

                    </tr>
                </thead>
                <tbody>


                    <tr>
                        <td> IBRAHIM AHMED</td>
                        <td>5335</td>
                    </tr>

                    <tr>

                        <td>MR AYMAN</td>
                        <td>5222</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>NEW BORN</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MS RABAB (SUP)</td>
                        <td>1603</td>

                    </tr>
                    <tr>

                        <td>DOCTOR ROOM</td>
                        <td>1605</td>

                    </tr>
                    <tr>
                        <td>NURSE STATION</td>
                        <td>1604/1606</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>INSFECTION CONTROL OFFICER</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR HAMZAH SHARAF ALDEN </td>
                        <td>7009</td>

                    </tr>
                    <tr>

                        <td>MR MOHD NASER/TARIQ</td>
                        <td>7009</td>

                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>MEDIA SERVICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR EHAB MAMOUN</td>
                        <td>3350</td>

                    </tr>
                    <tr>

                        <td>MR WALEED HASSAN</td>
                        <td>3352</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>IVF-CENTER</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>RECEPTION</td>
                        <td>1250/1251</td>

                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>STREEING COMMITTEE</th>
                        <th>5084-5085</th>

                    </tr>
                </thead>


            </table>
        </div>
        <div class="col-sm-6">

            <table class="table">
                <thead >
                    <tr>

                        <th>ASSISTANT COO OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>


                    <tr>
                        <td>ASSI CEO Office</td>
                        <td>6881</td>
                    </tr>
                    <tr>
                        <td>MR MOHAMED ANOWAR</td>
                        <td>5057</td>
                    </tr>

                    <tr>

                        <td>MS.SHERLIYN ESPIRITU</td>
                        <td>6608</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>CHIEF NURSING  OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MS.HODA A.HAMID</td>
                        <td>5880</td>

                    </tr>
                    <tr>

                        <td>SEC</td>
                        <td>5081</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>PC-DIR OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                  
                    <tr>

                        <td>MR AHMED QARI</td>
                        <td>5859</td>

                    </tr>
                    <tr>
                        <td>SEC</td>
                        <td>5162</td>
                    </tr>

                    <tr>
                        <td>RESERVATION DESK</td>
                        <td>5300/5337</td>
                    </tr>
                    <tr>
                        <td>OPD NURSING SUP</td>
                        <td>5220</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>SURGERY REC</th>
                        <th>5151</th>

                    </tr>
                </thead>
                <tbody>

                    <tr>

                        <td>DR.MOHD MOHI</td>
                        <td>5141</td>

                    </tr>
                    <tr>

                        <td>DR MOHMMED WAHID</td>
                        <td>5143</td>

                    </tr>

                    <tr>
                        <td>DR MOHMMOD ABO MUKARAM</td>
                        <td>5228</td>
                    </tr>

                    <tr>
                        <td>DR FARUK ALAFY</td>
                        <td>5142</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>ONCOLOGY REC</th>
                        <th>5223</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR EHAB ANWAR</td>
                        <td>5238</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>PEDIATRIC REC</th>
                        <th>5111</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>DR NABIL BADRAN</td>
                        <td>5121</td>
                    </tr>
                    <tr>

                        <td>DR.HANAN HALMEY</td>
                        <td>5296</td>

                    </tr>
                    <tr>

                        <td>DR SHOHA JALAL</td>
                        <td>5119</td>

                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>INT- MEDICINE</th>
                        <th>5223</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MOHAMMAD ABOU RAYYA</td>
                        <td>5237</td>

                    </tr>
                    <tr>

                        <td>DR AHMED MESRI</td>
                        <td>5239</td>

                    </tr>
                    <tr>
                        <td>DR MOHMMED REHAN</td>
                        <td>5248</td>
                    </tr>
                    <tr>
                        <td>DR AHAMED YASIN</td>
                        <td>5240</td>
                    </tr>
                    <tr>
                        <td>DR AMRO A.FATHU</td>
                        <td>5246</td>
                    </tr>
                    <tr>
                        <td>DR AHLAM MOHAMED</td>
                        <td>5247</td>
                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>ORTHOPEDIC REC</th>
                        <th>5267</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR AMEER MOKTAR</td>
                        <td>5258</td>

                    </tr>
                    <tr>


                        <td>DR AYMAN ALMASRY</td>
                        <td>5260</td>

                    </tr>
                    <tr>
                        <td>DR YASIR ALOKSH</td>
                        <td>5275</td>
                    </tr>
                    <tr>
                        <td>DR MAHAMOUD ALTAMEMY</td>
                        <td>5259</td>
                    </tr>
                    <tr>
                        <td>DR AHMED ALTURKEY</td>
                        <td>5274</td>
                    </tr>
                    <tr>
                        <td>DR MOHMMED HESHMAT</td>
                        <td>5275</td>
                    </tr>
                    <tr>
                        <td>DR EZZAT FOULY</td>
                        <td>5275</td>
                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>NEUROLOGY REC</th>
                        <th>5221</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR ZAKARIA ZAKARIA MOHAMMED</td>
                        <td>5229</td>

                    </tr>
                    <tr>

                        <td>DR OSAMA A.SALAM</td>
                        <td>5230</td>

                    </tr>
                </tbody>
                <thead >
                    <tr>

                        <th>NEUROSURGERY REC</th>
                        <th>5221</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MOHD ALNAGAR</td>
                        <td>5214</td>

                    </tr>
                    <tr>

                        <td>DR ASHRAF ALZAREEF</td>
                        <td>5215</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>PHYSIOTHERAPY	</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR HANY EBEID</td>
                        <td>6404</td>

                    </tr>
                    <tr>

                        <td>DR DALYA FOUAD</td>
                        <td>6416</td>

                    </tr>
                    <tr>
                        <td>DR MUHAMMED MOSLEH </td>
                        <td>6415</td>
                    </tr>


                </tbody>
                <thead >
                    <tr>

                        <th>CATH LAB</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>NURSE STATION</td>
                        <td>1545-1547</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>DELIVERY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR ROOM</td>
                        <td>1580</td>

                    </tr>
                    <tr>

                        <td>NURSE STATION</td>
                        <td>1583/1642</td>

                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>LABORATORY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR OSAMA FAYOMI</td>
                        <td>5830/5031</td>

                    </tr>
                    <tr>

                        <td>BLOOD BANK</td>
                        <td>5050/5019</td>

                    </tr>
                    <tr>
                        <td>HISTOPATHLOGY DOCTOR</td>
                        <td>5036</td>
                    </tr>
                    <tr>
                        <td>DR.AHAMED ELSAWY</td>
                        <td>5039</td>
                    </tr>
                    <tr>
                        <td>MARKETING (BLOOD)</td>
                        <td>5050/5045</td>
                    </tr>
                    <tr>
                        <td>MARKETING OFF</td>
                        <td>5053</td>
                    </tr>
                    <tr>
                        <td>MAIN RECEPTION(LAB)</td>
                        <td>5016/5017</td>
                    </tr>
                    <tr>
                        <td>MAIN RECEPTION(1)</td>
                        <td>5055</td>
                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>NURSING SUPERVISOR</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MS HAYAM ALI</td>
                        <td>2075/1278</td>

                    </tr>
                    <tr>

                        <td>MR MUHAMMAD JAMIL </td>
                        <td>2075/1279</td>

                    </tr>
                    <tr>
                        <td>MR FAROOQ RAJA</td>
                        <td>2075/1280</td>
                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>AL-HANOUF OFFICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MS.BEAUTY/RIAYZ</td>
                        <td>7013/1251</td>

                    </tr>
                    <tr>

                        <td>MR f.UDDIN/MR REAJ</td>
                        <td>6602/1252</td>

                    </tr>
                    <tr>
                        <td>FEMALE SECURITY</td>
                        <td>1297</td>
                    </tr>

                    <tr>
                        <td>MALE SECURITY</td>
                        <td>5358</td>
                    </tr>

                </tbody>
                <thead >
                    <tr>

                        <th>PHARMACY</th>


                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR MOHAMMAD BELTAGY</td>
                        <td>5890</td>

                    </tr>

                    <tr>
                        <td>DR IBRAHIM MOSAAD</td>
                        <td>6565</td>
                    </tr>
                    <tr>

                        <td>SENIOR PHARMACIST</td>
                        <td>5082/-5091</td>

                    </tr>

                    <tr>
                        <td>IN PATIENT PHARMACY</td>
                        <td>5063</td>
                    </tr>
                    <tr>
                        <td>OPERATOR</td>
                        <td>5095-5099</td>
                    </tr>

                    <tr>
                        <td>PHARMACY STORE</td>
                        <td>6441</td>
                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>MARKETING</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>Dr SALAH GALAL</td>
                        <td>7006</td>

                    </tr>
                    <tr>

                        <td>SECRETARY</td>
                        <td>5514/5513</td>

                    </tr>
                </tbody>
                <thead >
                    <tr>

                        <th>SUPPORT SERVICE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR FAYEZ AQEAL</td>
                        <td>6335/ 3108</td>

                    </tr>
                    <tr>


                        <td>MR AYMAN ALMEZANI</td>
                        <td>3108/3008</td>

                    </tr>
                    <tr>

                        <td>OPERATOR</td>
                        <td>6602</td>

                    </tr>


                </tbody>

                <thead >
                    <tr>

                        <th>WARE HOUSE</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR SULTAN/MR ZAFAR</td>
                        <td>6600/6562</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th> CSSD(C. STERILE)</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR.ISLAM</td>
                        <td>1561/1562</td>

                    </tr>
                    <tr>

                        <td>OPERATION THEATRE</td>
                        <td>1553/1554</td>

                    </tr>
                </tbody>

                <thead >
                    <tr>

                        <th>LAUNDRY</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR HABIB ZAIN</td>
                        <td>6311</td>

                    </tr>
                    <tr>

                        <td>TAILOR</td>
                        <td>6312</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>MTM</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>MR ESLAM KORANY</td>
                        <td>6871 / 6569</td>

                    </tr>
                    <tr>

                        <td>DR HOSAM MOHD</td>
                        <td>6565</td>

                    </tr>
                    <tr>
                        <td>MR TAREK SALAH</td>
                        <td>6563</td>
                    </tr>

                    <tr>

                        <td>Mr HAFIZ ABDULLAH</td>
                        <td>6568</td>

                    </tr>
                    <tr>

                        <td>MR RAJA FAROOQ</td>
                        <td>6563</td>

                    </tr>
                    <tr>
                        <td>SECRETARY</td>
                        <td>6567</td>
                    </tr>
                </tbody>

                <thead >
                    <tr>

                        <th>QPS</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>DR DALIA ANWAR</td>
                        <td>1252</td>

                    </tr>
                    <tr>

                        <td>MS BELEN PASCO</td>
                        <td>1253</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th>NURSE STATION(3RD FLR)</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>RECEPTION</td>
                        <td>3342-3343</td>

                    </tr>
                    <tr>

                        <td></td>
                        <td>3342-3343</td>

                    </tr>

                </tbody>

                <thead >
                    <tr>

                        <th> GENERAL WARD(1ST.FR)</th>

                    </tr>
                </thead>
                <tbody>
                    <tr>

                        <td>NURSING STATION(female)</td>
                        <td>1270/1271</td>

                    </tr>
                    <tr>

                        <td>NURSING STATION(Male)</td>
                        <td>1273/1274</td>

                    </tr>
                    <tr>
                        <td>DOCTOR ROOM</td>
                        <td>1253/1296</td>
                    </tr>

                </tbody>

                <tbody>
                    <tr>

                        <td>GREEN ROOM NO(1)</td>
                        <td>3341</td>

                    </tr>
                    <tr>

                        <td>GREEN ROOM NO(2)</td>
                        <td>3344</td>

                    </tr>
                    <tr>
                        <td>MEETING ROOM(1)</td>
                        <td>4111</td>
                    </tr>

                    <tr>
                        <td>MEETING ROOM(2)</td>
                        <td>4104</td>
                    </tr>

                    <tr>
                        <td>ARAMCO CLINIC</td>
                        <td>5061</td>
                    </tr>

                    <tr>
                        <td>NURSING EDUCATOR</td>
                        <td>7002</td>
                    </tr>
                    <tr>

                        <td>CLINICAL REVIEWER</td>
                        <td>1275</td>

                    </tr>
                    <tr>

                        <td>GROUP INTERNAL AUDITOR</td>
                        <td>3341</td>

                    </tr>
                    <tr>

                        <td>MR ERFAN( AUDITOR)</td>
                        <td>2025</td>

                    </tr>
                    <tr>

                        <td>MR MOHMMED AFIFI</td>
                        <td>4105</td>

                    </tr>


                </tbody>

            </table>

        </div>



    </div>
</div>




<?php include"includes/footer.php" ?>
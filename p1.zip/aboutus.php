﻿<?php include"includes/header.php" ?>



<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">About us </a>
        <a href="aboutus" class="list-group-item list-group-item-action">SGH Maddinah</a>
        <!--<a href="PresidentSpeech" class="list-group-item list-group-item-action">  President Letter</a>
<a href="ceoSpeech" class="list-group-item list-group-item-action">CEO Letter</a>-->
        <a href="missionVision" class="list-group-item list-group-item-action">Mission & Vision</a>
        <a href="excom" class="list-group-item list-group-item-action">Executive Committee</a>
    </div>
</div>
<div class="col-md-9">

    <div class="row">


        <h3>SGH Maddinah</h3><br>
        <div class="col-md-12" style="padding-top:5px"></div>

        <div class="col-md-5">

            <img class="card-img-left" src="files/images/002.jpg" alt="we care" style="width:270px;height:195px;">
        </div>


        <div class="col-md-7">
            <p class="text-justify">Middle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates 4 multi-specialty tertiary level hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>

        </div>
        <div class="col-md-12" style="padding-top:25px"></div>
        <div class="col-md-12">
            <p class="text-justify">SGH Madinah is a 184 beds multi-specialty tertiary care hospital under operations since 2003. The hospital is located in Madinah outside the Haram area conveniently located on Prince Naif bin AbdulAziz Road. The area is accessible to Muslims & non-Muslims. The hospital is built on a plot of 70,771 square meters, with the main hospital building having a built-up area of 34,751 square meters.</p>
    <br>
    <br>
    <br>
   
    
        </div>
        <br>
  

    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>

<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="cardiodepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="cardiomedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>
        <div class="col-md-3">
            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            Dr. Mohmmed Omer<br>
            Cardiology Department<br>
            Email:Cardiology4.med@sghgroup.net<br>
            Ext:5138
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <h5>Education</h5>
        </div>

        <div class="col-md-6">
         Consultant of Cardiology <br>
         MD - Al Azhar University <br>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>


    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
<?php include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>


    </div>
</div>

<div class="col-md-9" style="padding-top:25px;">

    <p>No Content</p>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
   
   
    <!--
<h4> Book 1 </h4>

<p>Click on the icon to download the book<p>
<a href="files/doc/test.pdf" download>
<img border="0" src="files/doc/test.pdf" alt="W3Schools" width="104" height="142">
</a>


<hr noshade>

<h4> Book 2 </h4>

<p>Click on the icon to download the book<p>
<a href="files/doc/test.pdf" download>
<img border="0" src="files/doc/test.pdf" alt="W3Schools" width="104" height="142">
</a>
-->


</div>


<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>SGH-MADINAH HELD A MEDICAL LECTURE COINCIDING WITH THE HAJJ FOR THE EMPLOYEES OF STC</strong></h4><br>
        <div class="col-md-12" style="text-align: center;">

            <img src="files/images/news3.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>
        <div class="col-md-12" style="padding-top:25px;"></div>

            <div class="col-md-12">
                <p class="text-justify">
                    As part of community service initiatives SGH-Madinah in cooperation with STC provided a free medical checkup, medical consultations and awareness lecture on infection control and dealing with symptoms and chronic diseases during Hajj for the staff of STC. These initiatives are based on the directives of Eng. Sobhi Batterjee to provide community services within the scope of social responsibility programs in the hospital, which aims to communicate continuously with various sectors in the region.</p>

            


        </div>
    </div>
</div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
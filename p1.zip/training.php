﻿<?php include"includes/header.php" ?>



<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>

    </div>
</div>
<div class="col-md-9">

    <h3>Training and Development Mission</h3><br>

    <p class="text-justify">The mission of our training and development staff is to promote and support employee development and organizational effectiveness by providing high-quality educational training programs. Trainings are designed to meet individual, group or departmental, and institutional needs and objectives. We strive to enhance individual learning and development as the means for creating a better workplace environment.</p>

</div>

<div class="col-md-12">
    <br><br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</div>


<?php include"includes/footer.php" ?>
﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>RECOVERING THE HEARING OF A PATIENT THROUGH THE SURGICAL MICROSCOPE</strong></h4><br>
        <div class="col-md-12" style="  text-align: center;">

            <img src="files/images/news5.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"></div>

            <div class="col-md-12">
                <p class="text-justify">
                    The doctors at SGH-Madinah were able to recover the hearing of a patient by the Surgical Microscope.The hospital said in a statement that the patient suffers from increased hearing impairment that hinders her activity and interaction with her family.the necessary tests were performed for the patient to identify the problem that led to the hearing impairment, it was found that the patient suffers from otosclerosis on both sides accompanied by increased hearing impairment, and she needs stapedotomy which is a surgical operation during which the ossified bone in the ear (stapes) which prevents the conduction of the sound is perforated and a small synthetic bone is placed through it connecting the other ossicles to the inner ear, stapedotomy was done through the “Surgical Microscope”.The statement added that the patient’s hearing was examined after stapedotomy and it turned out that there is no need for a headset, where the hearing returned completely without weakness.
                </p>

            </div>


        </div>
    </div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>IN COOPERATION WITH SGH-MADINAH FREE MEDICAL EXAMINATION FOR ROAD SECURITY COMMAND MEMBERS</strong></h4><br>
        <div class="col-md-12" style="text-align: center;">

            <img src="files/images/news4.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"> </div>

            <div class="col-md-12">
                <p class="text-justify">
                    As part of an initiative to serve the community, SGH-Madinah in cooperation with the Road Security Command presented one of its community programs, where the program was held at the road security headquarters in the region. The program included free medical examination, medical consultations and awareness lecture on how to deal with situations that may face the Road Security Command members while doing their work during the Hajj. These initiatives are taking place under the guidance of Eng. Sobhi Batterjee to provide community services, within the scope of social responsibility programs at the hospital, which aims at continuous communication with various sectors in the region.
                </p>

           


        </div>
    </div>
</div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
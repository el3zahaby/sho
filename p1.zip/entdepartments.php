<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9"  style="padding-top:25px;">

    <div class="row">

        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="entdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="entmedicalstaffdep.php" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <h3>ENT Services</h3><br>
        <p class="text-justify"><strong> Microscopic ear surgery:</strong><br>
            1- Tympanoplasties.<br>
            2- Mastoid atomies.<br>
            3- Myringotomy and grommet’s tube insertion.<br><br>

            <strong>Nasal surgeries-endoscopic assisted:<br></strong>
            1- Turbinctomy.<br>
            2- Septoplasty.<br>
            3- FESS.<br>
            4- Rhinoplasty.<br><br>

            <strong>Throat surgery:  <br> </strong>

            1- Microlaryngosurgery.<br>
            2- Adenotonsillectomy.<br>
            3- UPPP.<br>
            4- Cleft palate repair.</p><br><br>

        <div class="row" style="padding-top:25px;">
            <p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>Head of Department Ext:5207</p>
        </div>

    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
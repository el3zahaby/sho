﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>HEALING OF A PATIENT SUFFERING FROM CHRONIC ACUTE PANCREATIT</strong></h4><br>
        <div class="col-md-12" style="  text-align: center;">

            <img src="files/images/news7.jpg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"></div>

            <div class="col-md-12">
                <p class="text-justify">
                    A woman was diagnosed with acute and chronic pancreatitis due to a hereditary increase in triglycerides. The patient was admitted to the hospital during her eighth week of pregnancy after the death of the fetus in her womb; she was diagnosed of pancreatitis after she got twice pregnancy with the same problem and miscarried. After she came to the hospital suffering from severe abdominal pain, pleural effusion and respiratory failure, she was admitted to intensive care. The fluid in the abdomen has been removed by ultrasound catheterization and conservative treatment. The patient began to recover and she was miscarried in the operating room by a consultant gynecologist. She recovered gradually and left the hospital in a good health condition, but she will follow up with the Department of Thoracic Diseases because of the pleural effusion. The patient was warned not to re-pregnancy for her safety.
                </p>

            </div>


        </div>
    </div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
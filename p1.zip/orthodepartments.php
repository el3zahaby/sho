<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9"  style="padding-top:25px;">

    <div class="row">

        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="orthodepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="orthomedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <h3>Orthopedic Services</h3><br>
        <p class="text-justify">
            1- Management of all types of fractures especially fracture pelvis & fracture / 2- dislocation of all joints.<br>
            3- Advanced spine surgery & fracture / dislocation of the whole spine.<br>
            4- Spine deformities kyphosis, scoliosis, endoscopic spine surgery & LDP.<br>
            5- herapeutic local injection of joints & spine.<br>
            6- Use of Ozon, stem cells & plasma in management of different disorders.<br>
            7- Use of arthroscopy in knee, hip, shoulder, ankle and wrist disorders.<br>
            8- Upper limb, hand & microsurgery.<br>
            9- Joint arthroplasty either totalor hemi anomalies.<br>
            10- Pediatric orthropedic surgery, deformities & congenital.<br>
            11- Oncology, sport injuries & ilizarov.  <br>
        </p><br><br>

        <div class="row" style="padding-top:25px;">
            <p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>Head of Department Ext:5275</p>
        </div>

    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
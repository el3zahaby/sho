﻿<?php include'includes/header.php'?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Quality & Safety </a>
        <a href="cebahichapters" class="list-group-item list-group-item-action">Policies & procedures</a>
        <a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Protocols & Guidelines</a>
        <a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
        <a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
        <a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-7" >
            <!-- <div class="col-md-10" -->
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <!-- <div class="btn-group" role="group">
<a href="procedur&policy" class="btn btn-primary">Introduction</a>
</div>-->
                <div class="btn-group" role="group">
                    <a href="cebahichapters" class="btn btn-primary">General Polocies</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="deppolices" class="btn btn-primary">Departmental Policies</a>
                </div>

            </div>
        </div>

        <br> <br> <br>


        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"  >
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            IPSG
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput" onkeyup="search('myInput','myUL','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/IPSG/1.IPSG%201.pdf" class="list-group-item ">Patient Identification </a></li>
                                </div>



                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/2.%20IPSG%202.pdf" class="list-group-item "> Improve Effective Communication / Verbal and Telephone Order </a></li>
                                </div>


                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/3.IPSG%202.1.pdf" class="list-group-item ">Reporting Critical test Results of Diagnostic Tests
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/4.IPSG%202.2%20Hand%20Over%20hand%20off%20communcation.pdf" class="list-group-item ">Hand Over Hand Off Communcation</a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/5.policy%20019%20High%20Alert%20Policy.pdf" class="list-group-item ">High Alert Policy</a></li>
                                </div>

                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/6.POLICY%20020%20Concentrated%20Electrolyte%20Policy.pdf" class="list-group-item ">Concentrated Electrolyte Policy</a></li>
                                </div>


                            </div>



                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/7.POLICY-021-LASA-Policy.pdf" class="list-group-item ">LASA Policy</a></li>
                                </div>

                            </div>



                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/8.IPSG-4_-IPSG-4.1.pdf" class="list-group-item ">Ensure Safe Surgery</a></li>
                                </div>

                            </div>



                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/9.IPSG-5.pdf" class="list-group-item ">Hand Hygiene Policy</a></li>
                                </div>

                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/10.IPC004.1.pdf" class="list-group-item ">Hand Hygiene</a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/IPSG/11.IPC004.1.Annex.pdf" > Form</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/IPSG/12.IPSG-6.pdf" class="list-group-item ">Reduce the Risk of Patient Harm rRsulting From Fall</a></li>
                                </div>

                            </div>



                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTow" aria-expanded="false" aria-controls="collapseTow">
                            Infection Prevention & Control Policies and procedures
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseTow" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingTow">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput2" onkeyup="search('myInput2','myUL2','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL2" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/EHP/IPC_012.1Management_Of_Selected_Airborne_And_Droplet_Infectious_Disease_Exposures.PDF" class="list-group-item "> Management Of Selected Airborne And Droplet Infectious Disease Exposures
                                        In Healthcare Workers </a></li>
                                </div>


                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/EHP/IPC_012.2Exposure_Control_Services.PDF" class="list-group-item ">Exposure Control Services</a></li>
                                </div>

                            </div>
                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/EHP/IPC_012.3Immunization_Guidelines_For_Healthcare_Workers%20(1).PDF" class="list-group-item "> Immunization Guidelines For Healthcare Workers</a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/EHP/IPC_012.4Work_Restrictions_For_Infected_Healthcare_Workers.PDF" class="list-group-item "> Work Restrictions For Infected Healthcare Workers</a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/EHP/IPC_012_Employee_Occupational_Health_Program___Pre-Employment_Assessment.PDF" class="list-group-item ">Employee Occupational Health Program & Pre-Employment Assessment</a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/EHP/IPC_012.5Pregnant_Healthcare_Workers.PDF" class="list-group-item ">Pregnant Healthcare Workers & occupational health</a></li>
                                </div>

                            </div>


                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP001.PDF" class="list-group-item ">Infection Control Services</a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP002.PDF" class="list-group-item ">Infection Control Services - Departmental Mission / Vision / Objectives
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/IPC-DP002-vision.PDF" > Vision
                                                </a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP003.PDF" class="list-group-item ">Infection Control Department - Communication Chart
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/IPC-DP003-Communication_chart.pdf" >Communication Chart
                                                </a></li>
                                            <li><a href="files/doc/DPs/IPC-DP003-Organization_chart.pdf" >Orgnization Chart
                                                </a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP004.1.1.PDF" class="list-group-item ">Surveillance of Bloodstream Infections Associated with Intravascular Catheter</a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/AnnexIPC-DP4.1.1.PDF" > CLABSI </a></li>


                                        </ul>
                                    </div>
                                </div>

                            </div>



                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP004.1.2.PDF" class="list-group-item ">Surveillance of Urinary Tract Infections Associated with Indwelling Urinary Catheter</a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/AnnexIPC-DP4.1.2.PDF" > CAUTI</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP004.1.3.PDF" class="list-group-item "> Surveillance of ventilator associated pneumonia (VAP)
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/AnnexIPC-DP4.1.3.PDF" > VAE</a></li>

                                        </ul>

                                    </div>
                                </div>
                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP004.1.4.PDF" class="list-group-item ">Surveillance of Surgical Site Infections (SSI)

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/AnnexIPC-DP4.1.4.PDF" > SSI</a></li>

                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="row myli">

                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC-DP004.PDF" class="list-group-item ">Healthcare Associated Infections (HAI’s) Surveillance Guidelines </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPs/IPC_DP004.13.PDF" class="list-group-item ">Surveillance of Ventilator Associated Pneumonia (VAP)
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.1Chronic_Dialysis_Patients.PDF" class="list-group-item ">Prevention Of Transmission Of Infection Among Chronic Dialysis Patients
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.2_Serology_monitoring_for_hemodialysis_patients.PDF" class="list-group-item ">Serology Monitoring for Hemodialysis Patients
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.3_Hemodialysis-chemical_disinfection_fresenius_a_2008_c___e_hemodialysis_machines.PDF" class="list-group-item ">Hemodialysis-Chemical Disinfection Machines
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.4_External_cleaning_of_hemodialysis_machines.PDF" class="list-group-item ">External Cleaning of Hemodialysis Machines

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.5HEMODIALYSIS_%E2%80%93_CARE_OF_A-V_FISTULA.PDF" class="list-group-item ">Hemodialysis - Care of A-V Fistula

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.6_Hemodialysis_%E2%80%93_Dual_Lumen_Catheter_Dressing_Change_(Temporary_Vascular_Access).PDF" class="list-group-item ">Hemodialysis – Dual Lumen Catheter Dressing Change
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HDMANUAL/IPC_7.7.7_PREVENTION_AND_CONTROL_OF_BLOOD_BORNE_VIRUSES_IN_DIALYSIS_UNIT.PDF" class="list-group-item ">Prevention And Control Of Blood Borne Viruses In Dialysis Unit
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.1.PDF" class="list-group-item ">Infection Control in Laboratory Department
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.2%20(1).PDF" class="list-group-item ">Infection Control Guideline in Physiotherapy Department
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.3.PDF" class="list-group-item ">Infection Control Guideline in Imaging Services, Radiation and Interventional Radiology
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.4.PDF" class="list-group-item ">Infection Control Guideline in Operating Room
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.5.PDF" class="list-group-item ">Infection Control Guideline in Endoscopy Department
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC0010.5_Annex.PDF" >  Endoscopy record </a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0010.6.PDF" class="list-group-item "> Infection Control Guideline in Pharmacy Department
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC0011.1.PDF" class="list-group-item "> Notifications of Infection/Infectious Cases

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC0011.1_Annex.PDF" > ANNEX-I</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC008.3.PDF" class="list-group-item "> Curtain Policy

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC008.3_Annex.PDF" > Laundering Form</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC008.1.PDF" class="list-group-item "> Personal Protective Equipment’s (PPEs) & Emergency Plan

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC008.1_Annex.PDF" >  Form</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC002.0.PDF" class="list-group-item ">Infection Prevention and Control Program

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC002.1.PDF" class="list-group-item ">Infection Control Committee Responsibilities

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">


                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC002.2.PDF" class="list-group-item ">Job Description for Infection Prevention and Control Team (ICT)
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC002.3.PDF" class="list-group-item ">Infection Control Education and Training

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC002.3_Annex-I.pdf" >Attendance Sheet
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC002.3_Annex-II.pdf">Competency Checklist</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC003.0.PDF" class="list-group-item "> Infection Control Risk Assessment

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC003.0%20Annex-Annex-I.PDF" >WorkSheet</a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC003.0%20AnnexAnnex-II.PDF" > Risk Analysis </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC003.0-AnnexAnnex-III.pdf" >Control Plan</a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC003.0%20Annex-PRIORITY_LIST_ACCORDING_TO_RISK_ASSESSMENT_SCORING_(COMPLETED).PDF" >Assessment Scoring
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.1.PDF" class="list-group-item "> Hand Hygiene


                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.1_Annex.PDF" > Annex-I</a></li>

                                        </ul>

                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.10.PDF" class="list-group-item ">Single Use Medical Devices (SUD)

                                        </a></li>
                                </div>
                               
                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.2.PDF" class="list-group-item "> Environmental Services Cleaning Guidelines

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.2-Annex-I.pdf" > Cleaning Standards
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.2-Annex-II.PDF" >Cleaning Framework
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.2-Annex-III.pdf" > Cleaning Frequency</a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.2-Annex-IV.pdf" > Audit Report
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.2-Annex-V.PDF" >Audit Report 2</a></li>
                                        </ul>


                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.3.PDF" class="list-group-item ">Infection Control in Housekeeping


                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.3-AnnexI.PDF" > Chemical Supply
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.3-AnnexII.PDF" > Cleaning Checklist</a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.3-AnnexIII.PDF" > Cleaning Checklist 2</a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC004.3-AnnexIV.pdf" > Cleaning of Blood
                                                </a></li>

                                        </ul>


                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.4.PDF" class="list-group-item ">Sharps Disposal and Prevention of Sharp Injuries

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.5.PDF" class="list-group-item "> Infectious Waste Management.

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.6.PDF" class="list-group-item ">Linen & Upholstery Management – Laundry

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.7.PDF" class="list-group-item ">Pest Control

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.8.PDF" class="list-group-item ">Infection Control Guideline for Cleaning, Disinfection And Sterilization in CSSD & SGH-M

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC004.9.PDF" class="list-group-item ">Aseptic Techniques


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.1.PDF" class="list-group-item ">Standard Precautions



                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.10.PDF" class="list-group-item ">CAUTI
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.10-CAUTI_Annex-I.PDF" > Annex-1
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.10-CAUTI_Annex-II.PDF" >Annex-II
                                                </a></li>



                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.11.PDF" class="list-group-item ">Prevention of Ventilator Associated Pneumonia (VAP)


                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>

                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.11_Annex.PDF" > Check List
                                                </a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC05.3.PDF" class="list-group-item ">Multidrug Resistant Organisms Control and Bundle
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>

                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC05.3-AnnexI.PDF" > MDROs Bundle Form
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC05.3-AnnexII.PDF" > HCWs
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC05.3-AnnexIII.PDF" >Transfer Form
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC008.2.PDF" class="list-group-item ">Infection Control Education and Compliance of Patients, Sitters & Visitors During Isolation
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>

                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC008.2-Annex-I.PDF" > Annex-I
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC008.2-PEF%20Form.pdf" > Annex-II
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>

                            </div>


                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/DPS/IPC-DP005.PDF" class="list-group-item ">Elements Monitored During Isolation Rounds

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>

                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/DPs/AnnexIPC_DP005.PDF" > Annex-I
                                                </a></li>
                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.12.PDF" class="list-group-item ">Prevention of Surgical Site Infection
                                        (SSI)
                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.12-SSI_AnnexI.PDF" > Annex-I
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.12-SSI_AnnexII.PDF" >Annex-II
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.12-SSI_AnnexIII.PDF" > Annex-III</a></li>


                                        </ul>

                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.1.PDF" class="list-group-item ">Contact Isolation Policy


                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.2.PDF" class="list-group-item ">Droplet Isolation Policy


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.3.PDF" class="list-group-item ">Airborne Isolation Policy


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.4.PDF" class="list-group-item ">Initiating and Discontinuing Isolation


                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.5.PDF" class="list-group-item "> Negative Pressure Room Monitoring


                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.2.5_AnnexI.pdf" > Room Monitorig
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.2.5_AnnexII.PDF" > Room Maintenance Log
                                                </a></li>

                                        </ul>

                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.2.PDF" class="list-group-item ">Transmission Based Precautions

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>


                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.2-Airborn_Precaution.PDF" >Precautions Based Transmission
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.2-Contact_Precautions.PDF" >Contact Precautions
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.2-Droplet_precautions.PDF" > Precautions Based Transmission 2</a></li>
                                        </ul>
                                    </div>
                                </div>

                            </div>


                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.3.1.PDF" class="list-group-item ">Methicillin-Resistant Staphylococcus Aureus Management (MRSA)

                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.3.1_Annex.PDF" > MRSA Sheet</a></li>

                                        </ul>
                                    </div>
                                </div>

                            </div>


                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.3.2.PDF" class="list-group-item "> Vancomycin Resistant Enterococci Management (VRE)



                                        </a></li>
                                </div>


                            </div>


                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.3.PDF" class="list-group-item ">Multidrug Resistant Precautions (MDROs)



                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.4.PDF" class="list-group-item ">Viral Hemmorrhagic Fever (VHF)Management




                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.8.PDF" class="list-group-item ">Management of Patients With Suspected Sever Acute Respiratory Syndrome

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC005.9.PDF" class="list-group-item ">CLABSI



                                        </a></li>
                                </div>
                                <div class="col-md-1">
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-primary nor"  type="button" data-toggle="dropdown">
                                            <span class="glyphicon glyphicon-eye-open"></span></button>
                                        <ul class="dropdown-menu">
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.9-CLABSIAnnex-I.PDF" > Annex-I
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.9-CLABSIAnnex-II.PDF" >Annex-II
                                                </a></li>
                                            <li><a href="files/doc/HOSPITALPPGS/IPC005.9-CLABSIAnnex-III.PDF" > Annex-III</a></li>


                                        </ul>
                                    </div>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC006.0.PDF" class="list-group-item ">Infection Control Guideline In Kitchen and Food Service Hygiene



                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC006.1.PDF" class="list-group-item ">Post Exposure Prophylaxis of Needle Stick Injuries & Management of Exposure to Blood and Body
                                        Fluids



                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC007.10.PDF" class="list-group-item ">Infection Control Risk Assessment During Construction And Renovation



                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC007.11.PDF" class="list-group-item ">Post Mortum Care and Mortuary Care in SGH-M.



                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC007.12_.PDF" class="list-group-item "> Outbreak Investigation

                                        </a></li>
                                </div>

                            </div>


                            <div class="row myli">
                                <div class="col-md-10 ">
                                    <li><a href="files/doc/HOSPITALPPGS/IPC007.2.PDF" class="list-group-item ">Care of Immuno Compromised Patients

                                        </a></li>
                                </div>


                            </div>



                        </ul>
                    </div>
                </div>
            </div>


            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingThree">
                    <h4 class="panel-title">
                        <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Medication Managment
                        </a>
                        <br>
                    </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse " role="tabpanel" aria-labelledby="headingThree">
                    <div class="panel-body" >
                        <span class="tab-space">Effective date: 10/10/2017</span>  <span class="tab-space"> Review date 10/10/2017</span>
                        <span class="tab-space">
                            <input type="search" id="myInput3" onkeyup="search('myInput3','myUL3','myli')" placeholder="Search for names.." title="Type in a name">                                        </span>
                        <br><br>
                        <ul id="myUL3" >
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Adverse_drug_reaction.PDF" class="list-group-item ">Adverse Drug Reaction</a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/cbahi.terms_of_ref_of_p_t_commitee.PDF" class="list-group-item ">Pharmacy and Therapeutics Committee
                                        Term of reference </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Checklist_for_the_cleanness_of_the_pharmacy.PDF" class="list-group-item ">Checklist for the Cleanness of the Pharmacy </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Crash_Cart_Guidelines.PDF" class="list-group-item ">Crash Cart Medications Guidelines</a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/doctor_signature_2014.PDF" class="list-group-item ">List of Medical Staff Authorized to Prescribe Medication</a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/LASA_list.PDF" class="list-group-item "> List of LASA ( look-a-like and Sound-a-like ) Medications</a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/list_of_drug_can_be_order_by_telephone.PDF" class="list-group-item ">List of Drugs that can be ordered by Telephone</a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/list_of_drug_can_be_order_verbally.PDF" class="list-group-item ">List of Drugs that Can be Ordered Verbally
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/List_of_Hazardous_medications.PDF" class="list-group-item ">List of Hazardous Medications</a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/List_of_High_Alert.PDF" class="list-group-item ">List of High Alert Medications
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/list_of_restricted_antibiotic.PDF" class="list-group-item ">list of Restricted Antibiotic
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/med_error_form.PDF" class="list-group-item ">Medication Error Report Form
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Monthly_Ph_Inspections_for__nurse_station.PDF" class="list-group-item "> Inpatient Nursing Unit Inspections Form
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Monthly_Ph_Inspections_for_OPD.PDF" class="list-group-item ">Outpatient Clinics Inspection Form
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/non_availability_form.PDF" class="list-group-item ">Non Availability Form
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Non_Formulary_Medication_form.PDF" class="list-group-item ">Non Formulary Medication Form
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/pharmacists_competency_sheet.PDF" class="list-group-item ">Pharmacists Competency Sheet
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/pharmacy_intervention_form.PDF" class="list-group-item ">Pharmacy Intervention Form
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Policy_001Medication_Use_Management_.PDF" class="list-group-item ">Medication Use & Management
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_002_emergency_preparedness_plan.PDF" class="list-group-item ">Disaster Plan for Pharmacy Services
                                        </a></li>
                                </div>


                            </div>


                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Policy_003_QI_plan_policy_.PDF" class="list-group-item "> Pharmacy Quality Improvement Program

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_0043_privilege_policy_edited.PDF" class="list-group-item ">Medication Privileging Process
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_004_new_hired_orientationpolicy_.PDF" class="list-group-item "> Pharmacy New Hire Orientation Program
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_005_IC_guidelines_policy.PDF" class="list-group-item "> Infection Control guidelines For Pharmacy Services
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_006_Procurement___Purchasing_of_Medications.PDF" class="list-group-item ">Procurement & Purchasing of Medications
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_007_pharmacy___Therapeutic_committee.PDF" class="list-group-item ">Pharmacy and Therapeutics Committee
                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_008_drug_formulary.PDF" class="list-group-item ">Drug Formulary Policy

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_009_non-formulary_drug_edited_.PDF" class="list-group-item ">Procurement of Non-Formulary Medication

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_010_Obtaining_Out-of-Stock_Medications_and_closed.PDF" class="list-group-item ">Obtaining Out-of-Stock Medications and When Pharmacy is Closed
                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_011_OVERSEEING_MEDICATION_USE_edited_.PDF" class="list-group-item ">Overseeing Medication Use

                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_012_STORAGE_OF_MEDICATION.PDF" class="list-group-item ">Storage of Regular Medications in Stores, Pharmacies, and Patient Care Areas


                                        </a></li>
                                </div>



                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_013_STORAGE_OF_REF._MEDICATION.PDF" class="list-group-item ">Storage of Refrigerated and Frozen Medications Biological and Vaccine in Store , Pharmacies and
                                        Patient Care Areas

                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_014_floor_stock.PDF" class="list-group-item ">Floor Stock
                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_015_storage_of_nutriotion_Products.PDF" class="list-group-item ">Handling of Nutritional Products


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_016_Storage_of_Radio_Active_Material.PDF" class="list-group-item "> Handling of Radio Active Medication
                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_017_Emergency_and_Crash_Cart_Medications.PDF"
                                           class="list-group-item ">Emergency and Crash Cart Medications

                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_018_Patient_s_Own_Medication__.PDF" class="list-group-item ">Patient's Own Medication

                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_019_High_Alert_Policy.PDF" class="list-group-item ">Improve the Safety of High Alert Medication

                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_020_Concentrated_Electrolyte_Policy.PDF" class="list-group-item "> Improve the Safety of Concentrated Electrolyte Solutions


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_021_LASA_Policy.PDF" class="list-group-item "> Improve the Safety of Look-alike and Sound-alike (LASA) Medications

                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_022_Hazardoues_pharmaceutical_chemical_Policy.PDF" class="list-group-item "> Improve the Safety of Hazardous Pharmaceutical Chemicals


                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_023_Safe_Handling_of_Medications_and_Chemicals..PDF" class="list-group-item "> Safe Handling of Medications and Chemicals

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_024_4Distribution_and_Control_of_Narcotic_and.PDF" class="list-group-item "> Distribution and Control of Narcotic and Controlled Drugs


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_025_Medications__Recall_System.PDF" class="list-group-item ">  Medications Recall System


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_026_Handling_Medication_Samples_.PDF" class="list-group-item "> Handling Medication Samples

                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_027_Handling_of_Nearly_Expiry_Medication___Pharmaceutical_Waste_edited..PDF" class="list-group-item "> Handling of Nearly Expiry Medication, Outdated & Pharmaceutical Waste

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_028_Pharmacy_Intervention.PDF" class="list-group-item "> Pharmacy Intervention

                                        </a></li>
                                </div>

                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_029_Doctor_s_Order.PDF" class="list-group-item "> Medication Orders

                                        </a></li>
                                </div>



                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_030_Medication_Reconciliation_Policy.PDF" class="list-group-item "> Medication Reconciliation Policy
                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_031_Antibiotic_Policy__modified.PDF" class="list-group-item "> Antibiotic Policy


                                        </a></li>
                                </div>


                            </div>

                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_032_Prescribing__Ordering_and_Transcribing.PDF" class="list-group-item "> Prescribing, Ordering and Transcribing



                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_033_APPROPRIATNESS_OF_MEDICATION.25.PDF" class="list-group-item ">  Medication Review for Appropriateness


                                        </a></li>
                                </div>



                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_034_Automatic_Stop_Orders.PDF" class="list-group-item "> Automatic Stop Orders


                                        </a></li>
                                </div>



                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_035_Unit_Dose_Dispensing_System_(UDDDS)_.PDF" class="list-group-item "> Unit Dose Dispensing System (UDDS)


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_036_Dispensing__Checking_and_Counseling.PDF" class="list-group-item "> Dispensing, Checking and Counseling



                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_037_General_Intravenous_Admixture_Policies.PDF" class="list-group-item "> General Intravenous Admixture Policies



                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_038__Safe_Handling_of_Cytotoxic_Hazardous_Drugs_.PDF" class="list-group-item ">Safe Handling of Cytotoxic Hazardous Drugs



                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_039_medication_preparation_and_administration.PDF" class="list-group-item ">Medication Preparation and Administration


                                        </a></li>
                                </div>



                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_040_Verifying_Correct_Medications_Administration.PDF" class="list-group-item "> Verifying Correct Medications Administration


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/policy_041_Monitoring_the_Effect___Adverse_Effects_of_Medications.PDF" class="list-group-item "> Monitoring the Effect & Adverse Effects of Medications


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/POLICY_042_Medication_Error_Policy.PDF" class="list-group-item "> Handling of Medication Errors,Near Misses, and Hazardous Situations


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/privilege_new_.PDF" class="list-group-item ">list of Medical Staff Prescribing Privileges
                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/privilege_new_edited_.PDF" class="list-group-item ">list of Medical Staff Prescribing Privileges


                                        </a></li>
                                </div>



                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Standard_Chemotherapy_concentration.PDF" class="list-group-item "> Standard Concentrations for Chemotherapy Medications


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/standard_dilutions.PDF" class="list-group-item ">Standard Dilutions


                                        </a></li>
                                </div>


                            </div>
                            <div class="row myli">

                                <div class="col-md-10">
                                    <li><a href="files/doc/MMU/Standard_High_Alert_Concentration.odt_(1).PDF" class="list-group-item "> Standard Concentrations for High Alert Medications


                                        </a></li>
                                </div>


                            </div>



                        </ul>
                    </div>
                </div>
            </div>




        </div>
    </div>
</div>


<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>
<?php include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>


    </div>
</div>

<div class="col-md-9" style="padding-top:25px;">

    <h4><STRONG>How Incredibly Successful People Think</STRONG>  </h4>
    <h5> Date : 12\10\2017</h5>
    <br>
    <div class="embed-responsive embed-responsive-16by9">
        <video width="320" height="240" controls>
            <source src="files/vid/HR/How%20Incredibly%20Successful%20People%20THINK-1.mp4" type="video/mp4">
        </video>

    </div>


    <hr noshade>

    <h4><STRONG> Lead and be the change Mark Mueller-Eberstein at TEDxRainier</STRONG>  </h4>
    <h5> Date : 12\10\2017</h5>
    <br>
    <div class="embed-responsive embed-responsive-16by9">
        <video width="320" height="240" controls>
            <source src="files/vid/HR/Lead%20and%20be%20the%20change%20Mark%20Mueller-Eberstein%20at%20TEDxRainier.mp4" type="video/mp4">
        </video>
    </div>

    <hr noshade>

    <h4><STRONG> The benefits of good posture - Murat Dalkilinç</STRONG>  </h4>
    <h5> Date : 12\10\2017</h5>
    <br>
    <div class="embed-responsive embed-responsive-16by9">
        <video width="320" height="240" controls>
            <source src="files/vid/HR/The%20benefits%20of%20good%20posture%20-%20Murat%20Dalkilin%C3%A7%20-%20YouTube%5Bvia%20torchbrowser.com%5D.mp4" type="video/mp4">
        </video>
    </div>

    <hr noshade>

    <h4> <STRONG>Why it pays to work hard - Richard St. John</STRONG> </h4>
    <h5> Date : 12\10\2017</h5>
    <br>
    <div class="embed-responsive embed-responsive-16by9">
        <video width="320" height="240" controls>
            <source src="files/vid/HR/Why%20it%20pays%20to%20work%20hard%20-%20Richard%20St.%20John.mp4" type="video/mp4">
        </video>
    </div>

    <hr noshade>

    <h4><STRONG> The importance of focus - Richard St. John</STRONG>  </h4>
    <h5> Date : 4\5\2017</h5>
    <br>
    <div class="embed-responsive embed-responsive-16by9">
        <video width="320" height="240" controls>
            <source src="files/vid/HR/The%20importance%20of%20focus%20-%20Richard%20St.%20John.mp4" type="video/mp4">
        </video>
    </div>


</div>


<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
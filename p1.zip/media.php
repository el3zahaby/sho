﻿<?php include"includes/header.php" ?>



<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="media" class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9">

    <div class="row">


        <h3>Introduction </h3><br>
        <div class="col-md-12" ></div>

        <div class="col-md-5">
            <p class="text-justify"> Healthcare CompHealthcare Comp Healthcare Compddle  Healthcare Comp  Healthcare CompEast Healthcare Company Middle East Healthcare CompanyMiddle East Healthcare Company (MEAHCO) is the largest healthcare provider in the Kingdom of Saudi Arabia, founded by Batterjee family, owns and operates network of state-of-the art hospitals under the brand name - Saudi German Hospitals. Currently MEAHCO operates </p>

        </div>

        <div class="col-md-5">

            <img class="card-img-left" src="files/images/005.jpg" alt="media" style="width:320px;height:250px;">
        </div>



        <div class="col-md-11">
            <p class="text-justify">Middle East  Healthcare Comp  Healthcare Comp  Healthcare Comp Healthcare Co Certiary levelo Certiary level hospito Certiary level hospit hospitals in the Kingdom of Saudi Arabia (Jeddah, Riyadh, Madinah, Aseer). The hospitals in Hail and Dammam are in the various stages of execution.</p>
        </div>


    </div>

</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>



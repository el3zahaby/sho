<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9"  style="padding-top:25px;">

    <div class="row">

        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="obdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="obmedicalstaffdep.php" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <h3>OBS & GYNE Services </h3><br>
        <p class="text-justify">

            1- Antenatal Care.<br>
            2- Transvaginal Folliculometry.<br>
            3- Painless Labor.<br>
            4- Contraceptive methods.<br>
            5- 3D ultrasonography.<br>
            6- Diagnostic and operative gyne endoscopy.<br>
            7- Management of infertility.<br>
            8- Gynecological oncology operations.<br>

        </p><br><br>

        <div class="row" style="padding-top:25px;">
            <p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>Head of Department Ext:5284</p>
        </div>

    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
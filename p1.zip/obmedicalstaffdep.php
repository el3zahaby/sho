<?php include 'includes/header.php' ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="obdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="obmedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">
            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4> Head of Department</h4>
            <hr noshade>
            Dr. Hamed Shalby<br>
            Obstetrics & Gynecology Department<br>
            Email:Obgyn1.med@sghgroup.net<br>
            Ext:5284 	 <p class="text-right"><a href="ob1drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/islam.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Counsultant</h4>
            <hr noshade>
            Dr.Islam Mohmmed<br>
            Obstetrics & Gynecology Department<br>
            Email:Obgyn2.med@sghgroup.net<br>
            Ext:5288 <p class="text-right"><a href="ob2drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>
        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/b.%20talaat.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Counsultant</h4>
            <hr noshade>
            Dr.Bassem Tallat<br>
            Obstetrics & Gynecology Department<br>
            Email:Obgyn6.med@sghgroup.net<br>
            Ext:5286 <p class="text-right"><a href="ob3drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>




        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4> Registrar</h4>
            <hr noshade>
            Dr.Aida Qassem<br>
            Obstetrics & Gynecology Department<br>
            Email:Obgyn8.med@sghgroup.net<br>
            Ext:5290 <p class="text-right"><a href="ob4drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4> Registrar</h4>
            <hr noshade>
            Dr.Nashan Farg<br>
            Obstetrics & Gynecology Department<br>
            Email:Obgyn10.med@sghgroup.net<br>
            Ext:5291 <p class="text-right"><a href="ob5drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4>Registrar</h4>
            <hr noshade>
            Dr.Marwa Samer<br>
            Obstetrics & Gynecology Department<br>
            Ext:5290 <p class="text-right"><a href="ob6drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>




    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>
<?php include 'includes/footer.php' ?>
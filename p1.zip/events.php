﻿<?php include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">

    <div class="row">

        <div class="col-md-4">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/spevents022.jpg" alt="Card image cap">
                <div class="card-body">
                    <a href="spevents2" class="list-group-item "><h4 class="card-title">SAUDI NATIONAL <br> DAY</h4></a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card" style="height:100%">
                <img class="img-responsive" src="files/images/spevent01.jpg" alt="Card image cap">
                <div class="card-body">
                    <a href="spevents" class="list-group-item ">
                        <h4 class="card-title">DEVELOPMENT AUTHORITY </h4></a>
                </div>
            </div>
        </div>



        <div class="col-md-12" style="padding-top:25px"></div>







    </div>


</div>

<div class="col-md-12">
    <br><br>
     <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</div>

<?php include"includes/footer.php" ?>
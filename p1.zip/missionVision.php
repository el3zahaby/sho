﻿<?php include 'includes/header.php' ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active">About us </a>
        <a href="aboutus" class="list-group-item list-group-item-action">SGH Maddinah</a>
        <!--<a href="PresidentSpeech" class="list-group-item list-group-item-action"> President Letter</a>
<a href="ceoSpeech" class="list-group-item list-group-item-action">CEO Letter</a> -->
        <a href="missionVision" class="list-group-item list-group-item-action">Mission & Vision</a>
        <a href="excom" class="list-group-item list-group-item-action">Executive Committee</a>
    </div>
</div>
<div class="col-md-9">
    <div class="row">


        <h3>Mission </h3><br>

        <p class="text-justify">
            Saudi German Hospital Maddinah team is committed to providing superior clinical services that add value to our patients, their families, our stakeholders and our community as a whole.</p>
        <h3>Vision </h3><br>
        <p class="text-justify">The Saudi-German Hospital is the first provider of health services provided at the level of hospitals, which provide a distinguished service to the patient at a high level of quality</p>

 <br>
    <br>
    <br>
    <br>
    <br>
  






    </div>

</div>

<div class="col-md-12">
    <br><br>
</div>
<?php include 'includes/footer.php' ?>

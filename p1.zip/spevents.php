﻿<?php include"includes/header.php" ?>


`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" >

    <div class="row">


        <h3>DEVELOPMENT AUTHORITY IN MADINAH</h3><br>
        <div class="col-md-12" ></div>

        <div class="col-md-12">
            <p class="text-justify">
                SGH - Madinah provides comprehensive medical examination to government sectors officials at the Development Authority in Madinah. Engr. Mohamed Al Amri the Secretary of Madinah area listened to a brief explanation for the service provided by the hospital.
            </p>
            <br>

        </div>


        <div class="col-md-6">
            <div  style="height:100%">
                <img class="card-img-left"src="files/images/spevent011.jpg" alt="Card image cap" style="width:300px;height:250px;">

            </div>
        </div>

        <div class="col-md-6">
            <div  style="height:100%">
                <img class="card-img-right"src="files/images/spevent0012.jpg" alt="Card image cap" style="width:300px;height:250px;">

            </div>
        </div>



    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>



<?php include"includes/footer.php" ?>
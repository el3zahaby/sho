<?php include 'includes/header.php' ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="surgdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="surgmedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">
            <img class="card-img-top" src="files/images/doc/mohey.jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4> Head of Department</h4>
            <hr noshade>
            Dr. Mohmmed Mohiy<br>
            Surgery Department<br>
            Email:Surgery1.med@sghgroup.net<br>
            Ext:5141 	 <p class="text-right"><a href="surg1drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/m.%20waheed.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Consultant</h4>
            <hr noshade>
            Dr.Mohmmed Wahid<br>
            Surgery Department<br>
            Ext:5143 <p class="text-right"><a href="surg2drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/abulmajarem.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Specialist</h4>
            <hr noshade>
            Dr.Mahmood Abo Almakarem<br>
            Surgery Department<br>
            Email:Surgery4.med@sghgroup.net<br>
            Ext:5228 <p class="text-right"><a href="surg3drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/farouk.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Vascular Consultant</h4>
            <hr noshade>
            Dr.Farooq Alalfy<br>
            Surgery Department<br>
            Email:Surgery6.med@sghgroup.net<br>
            Ext:5142 <p class="text-right"><a href="surg4drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>



    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>
<?php include 'includes/footer.php' ?>
﻿<?php include"includes/header.php" ?>



`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:1px;">

    <div class="row">


        <h4><strong>SUCCESSFUL SURGERY TO CULTIVATE THE CORONARY ARTERY AT SGH- MADINAH</strong></h4><br>
        <div class="col-md-12" style="  text-align: center;">

            <img src="files/images/news8.jpeg"
                 alt="SGH-Madinah participation in Urology Club Meeting "
                 width="555" height="416" >

        </div>

        <div class="col-md-12" style="padding-top:25px;"></div>

            <div class="col-md-12">
                <p class="text-justify">
                    A medical team at SGH- Madinah was able to perform a rare and large surgery for a patient had difficulty swallowing. After the tests were performed for the patient a congenital defect was found at the place of the aorta and the left subclavian artery, in addition to aortic aneurysm in the position of the protrusion of the left subclavian artery behind the esophagus, it was a great pressure on the esophagus which led to difficulty swallowing. A medical team of cardiac, chest, vascular, anesthesia and central care surgeons was immediately formed to develop the treatment plan before, during and after surgery. The patient was admitted to the operating room and a thoracic incision was made to detect the aortic aneurysm, the doctors removed it and transplanted the left subclavian artery in the left artery by a small wound in the neck. The patient recovered well after the treatment of the aortic aneurysm and the pain of difficulty swallowing disappeared, and the patient resumed her daily activities.
                </p>

            </div>


        </div>
    </div>

    <div class="col-md-12">
        <br><br>
    </div>



    <?php include"includes/footer.php" ?>
﻿<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>

    </div>
</div>
<div class="col-md-9">

    <h3> Course List </h3><br>
    <table class="table">

        <tr>
            <td ><h5>Fire Fighting</h5></td>
            <td >17-10-2017</td>
            <td > <a class="nav-link" href="coursedetails2">Read More</a></td>
        </tr>

        <tr>
            <td ><h5>Patient Satisfaction Program</h5></td>
            <td >10-10-2017</td>
            <td><a class="nav-link" href="coursedetails">Read More</a><td>
        </tr>

    </table>
</div>

<div class="col-md-12">
    <br><br>
     <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</div>


<?php include"includes/footer.php" ?>
<?php include 'includes/header.php' ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">
    <div class="row">
        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="imdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="immedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">
            <img class="card-img-top" src="files/images/doc/amr.jpg" alt="doc" >
        </div>

        <div class="col-md-6">
            <h4> Head of Department<br>Consultant of digestive system</h4>

            <hr noshade>
            Dr. Amro Abo Alftooh <br>
            Internal Medicine Department<br>
            Email:im3.med@sghgroup.net<br>
            Ext:5246 	 <p class="text-right"><a href="im1drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>


        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/rehan.jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Consultant of pressure, sugar and endocrine</h4>
            <hr noshade>
            Dr.Mohmmed Rehan<br>
            Internal Medicine Department<br>
            Email:im7.med@sghgroup.net<br>
            Ext:5248 <p class="text-right"><a href="im2drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <div class="col-md-3">

            <img class="card-img-top" src="files/images/doc/doc-icon%20(3).jpg" alt="doc" >
        </div>


        <div class="col-md-6">
            <h4> Counsultant</h4>
            <hr noshade>
            Dr.Ahlam Mohmmed<br>
            Internal Medicine Department<br>
            Email:.med@sghgroup.net<br>
            Ext:5247 <p class="text-right"><a href="im3drdep"> More Doctor Info</a></p>
            <hr noshade>
        </div>






    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>
<?php include 'includes/footer.php' ?>
﻿<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active  ">Quality & Safety </a>
        <a href="cebahichapters" class="list-group-item list-group-item-action">Policies & procedures</a>
        <a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Procedures & Guidelines</a>
        <a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
        <a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
        <a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">

    <p>No Content</p>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <!--
<h4> Tiltle of presentation  </h4>
<h5> Date : 4\5\2017</h5>
<h5> Prepared By: Dr.Dalia </h5>
<br>
<p>Click on the icon to download the book<p>

<a href="files/doc/test.pdf" download>
<img border="0" src="files/doc/test.pdf" alt="W3Schools" width="104" height="142">
</a>


<hr noshade>

<h4> Tiltle of presentation  </h4>
<h5> Date : 4\5\2017</h5>
<h5> Prepared By: Dr.Dalia </h5>
<br>
<p>Click on the icon to download the book<p>

<a href="files/doc/test.pdf" download>
<img border="0" src="files/doc/test.pdf" alt="W3Schools" width="104" height="142">
</a>
-->

</div>



<div class="col-md-12">
    <br><br>
</div>



<?php include"includes/footer.php" ?>
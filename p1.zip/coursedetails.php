﻿
<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>

    </div>
</div>
<div class="col-md-9">
    <div class="table-responsive">
        <table class="table">

            <h3> Course Deatils</h3>

            <tr>
                <td class="success" ><strong>COURSE TITEL </strong></td>
                <td > Patient Satisfaction Program </td>
                <td class="success"><strong>PRESENTED BY</strong></td>
                <td >Dr. Mohamed Talaat (Senior ER Registrar) </td>


            </tr>

            <tr>
                <td class="success"><strong>DATE-FROM</strong></td>
                <td >10-10-2017</td>
                <td class="success"><strong>DATE-TO</strong></td>
                <td >10-10-2017</td>

            </tr>
            <tr>
                <td class="success"><strong>TIME-FROM</strong> </td>
                <td >12:00 PM</td>
                <td class="success"><strong>TIME-TO</strong></td>
                <td >1:30 PM</td>

            </tr>
            <tr>
                <td class="success" ><strong>PLACE</strong> </td>
                <td >Auditorium, 3rd Floor </td>
                <td  class="success"><strong>LANGUGE</strong></td>
                <td >English</td>
            </tr>
        </table>
    </div>

    <h3>Course Presentaion</h3><br>



    <div class="col-md-10 ">
        <li class="list-group-item ">
            <a href="vfile.php?file=files/doc/HRCOURSES/Patient Satisfaction Program.PDF">
                Patient Satisfaction Program
            </a></li>
    </div>




</div>

<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>
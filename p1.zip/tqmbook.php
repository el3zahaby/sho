﻿<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Quality & Safety </a>
        <a href="cebahichapters" class="list-group-item list-group-item-action">Policies & procedures</a>
        <a href="clinicalchapters" class="list-group-item list-group-item-action">Clinical Procedures & Guidelines</a>
        <a href="tqmbook" class="list-group-item list-group-item-action">Books</a>
        <a href="tqmpresentation" class="list-group-item list-group-item-action">Orientations</a>
        <a href="tqmvedio" class="list-group-item list-group-item-action">videos</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">


    <div class="row">
        <div class="col-sm-6">
            <h4> <STRONG>CBAHI Standards </STRONG></h4>

            <p>Click on the icon to download the book<p>
            <a href="files/doc/TQMBOOK/CBAHI%20standards..pdf" download>
                <img border="0" src="files/images/BOOK.jpg" alt="CBAHI Standards" width="104" height="142">
            </a>
        </div>
        <div class="col-sm-6">
            <h4><STRONG>BNF</STRONG>  </h4>

            <p>Click on the icon to download the book<p>
            <a href="files/doc/TQMBOOK/BNF%20%20sep.2009.pdf" download>
                <img border="0" src="files/images/BOOK.jpg" alt="W3Schools" width="104" height="142">
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-6">
            <h4><STRONG>JCI Standards</STRONG>  </h4>

            <p>Click on the icon to download the book<p>
            <a href="files/doc/TQMBOOK/JCI%206th%20standards.%20(1).pdf" download>
                <img border="0" src="files/images/BOOK.jpg" alt="W3Schools" width="104" height="142">
            </a>

        </div>
        <div class="col-sm-6">
            <h4> <STRONG>Martindale</STRONG></h4>

            <p>Click on the icon to download the book<p>
            <a href="files/doc/TQMBOOK/Martindale36.pdf" download>
                <img border="0" src="files/images/BOOK.jpg" alt="W3Schools" width="104" height="142">
            </a>

        </div>
    </div>


    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>



</div>


<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
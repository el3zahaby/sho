﻿<?php include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" style="padding-top:25px;">

    <div class="row">

        <h4>SGH-MADINAH PARTICIPATION IN UROLOGY CLUB MEETING</h4>
        <h6>20 SEPTEMBER 2017</h6>

        <p class="text-right"><a href="spnews1"> Read More</a></p>

        <hr noshade>

        <h4>INFECTION CONTROL DURING HAJJ SEASON</h4>
        <h6>10 SEPTEMBER 2017</h6>
        <p class="text-right"><a href="spnews2"> Read More</a></p>

        <hr noshade>

        <h4>SGH-MADINAH HELD A MEDICAL LECTURE COINCIDING WITH THE HAJJ FOR THE EMPLOYEES OF STC</h4>
        <h6>22 AUGUST 2017</h6>
        <p class="text-right"><a href="spnews3"> Read More</a></p>


        <hr noshade>

        <h4>IN COOPERATION WITH SGH-MADINAH FREE MEDICAL EXAMINATION FOR ROAD SECURITY COMMAND MEMBERS</h4>
        <h6>15 AUGUST 2017</h6>
        <p class="text-right"><a href="spnews4"> Read More</a></p>


        <hr noshade>

        <h4>RECOVERING THE HEARING OF A PATIENT THROUGH THE SURGICAL MICROSCOPE</h4>
        <h6>19 JULY 2017</h6>
        <p class="text-right"><a href="spnews5"> Read More</a></p>

        <hr noshade>


        <h4>VISIT OF KATSINA STATE GOVERNOR FROM NIGERIA TO SGH MADINAH</h4>
        <h6>6 JULY 2017</h6>
        <p class="text-right"><a href="spnews6"> Read More</a></p>

        <hr noshade>

        <h4>HEALING OF A PATIENT SUFFERING FROM CHRONIC ACUTE PANCREATIT</h4>
        <h6>8 JUNE 2017</h6>
        <p class="text-right"><a href="spnews7"> Read More</a></p>

        <hr noshade>


        <h4>SUCCESSFUL SURGERY TO CULTIVATE THE CORONARY ARTERY AT SGH- MADINAH</h4>
        <h6>20 MAY 2017</h6>
        <p class="text-right"><a href="spnews8"> Read More</a></p>

        <hr noshade>
    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
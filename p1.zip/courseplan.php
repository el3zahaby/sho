<?php include"includes/header.php" ?>

<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="training" class="list-group-item active ">Training </a>
        <a href="courseplan" class="list-group-item list-group-item-action">Courses Plan</a>
        <a href="courses" class="list-group-item list-group-item-action">Courses</a>
        <a href="hrbook" class="list-group-item list-group-item-action">Books</a>
        <a href="hrpresentation" class="list-group-item list-group-item-action">Presentations</a>
        <a href="hrvedio" class="list-group-item list-group-item-action">videos</a>


    </div>
</div>

<div class="col-md-9" style="padding-top:25px;"></div>
<div class="col-md-9 ">

    <h4> <strong>Courses Plan</strong> </h4>


    <li class="list-group-item ">
        <a href="vfile.php?file=files/doc/COURSEPLAN/October%20Course%20Plan.pdf">
            October Course Plan
        </a></li>
</div>









<div class="col-md-12">
    <br><br>
     <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
</div>


<?php include"includes/footer.php" ?>
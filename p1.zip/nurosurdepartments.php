<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9"  style="padding-top:25px;">

    <div class="row">

        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="nurosurdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="nurosurmedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <h3>  Neurosurgery Services</h3><br>
        <p class="text-justify">
            1- Surgical management of cervical & lumbar disc herniation.<br>
            2- Surgical excision of brain and spinal cord tumors.<br>
            3- Management of traumatic brain & spin injuries.<br>

        </p><br><br>

        <div class="row" style="padding-top:25px;">
            <p><span class="glyphicon glyphicon-phone-alt" aria-hidden="true"></span>Head of Department Ext:5214</p>
        </div>

    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
﻿<?php include"includes/header.php" ?>


`
<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a class="list-group-item active ">Media </a>
        <a href="news" class="list-group-item list-group-item-action">News</a>
        <a href="events" class="list-group-item list-group-item-action">Events</a>
    </div>
</div>
<div class="col-md-9" >

    <div class="row">


        <h3>SUADI NATIONAL DAY</h3><br>
        <div class="col-md-12" ></div>

        <div class="col-md-12">
            <p class="text-justify">
                The Saudi German Hospital in Madinah celebrated the 87th National Day of the Kingdom of Saudi Arabia and the memories of its unification by His Majesty King Abdulaziz Al Saud.

                Where a large ceremony was held inside the hospital at this occasion attended by staff and auditors.
                While the ceremony included several entertainment paragraphs and took the hospital in green, glorifying the memory of Ghali on the heart of every citizen

                The director of the Saudi German Hospital gave a speech on this occasion
                He also conveyed the highest congratulations to the Custodian of the Two Holy Mosques, King Salman Bin Abdul Aziz, and to His Highness the Crown Prince, His Royal Highness Prince Mohammed bin Salman, asking God to preserve this country and preserve the blessing of security and safety
            </p>
            <br>

        </div>


        <div class="col-md-6">
            <div  style="height:100%">
                <img class="card-img-left"src="files/images/spevents021.jpg" alt="Card image cap" style="width:340px;height:250px;">

            </div>
        </div>

        <div class="col-md-6">
            <div  style="height:100%">
                <img class="card-img-right"src="files/images/spevents022.jpg" alt="Card image cap" style="width:340px;height:250px;">

            </div>
        </div>



    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>



<?php include"includes/footer.php" ?>
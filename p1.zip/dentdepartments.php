<?php include"includes/header.php" ?>


<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a href="departmentcenters" class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>
<div class="col-md-9"  style="padding-top:25px;">

    <div class="row">

        <div class="col-md-5" >
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
                <div class="btn-group" role="group">
                    <a href="dentdepartments" class='btn btn-primary'>Services</a>
                </div>
                <div class="btn-group" role="group">
                    <a href="dentmedicalstaffdep" class='btn btn-primary'>Medical Staff</a>
                </div>

            </div>
        </div>

        <div class="col-md-12" style="padding-top:25px"></div>

        <h3>Dentistry Services </h3><br>
        <p class="text-justify">

            This department is operated under care of highly western qualified dental and technical professionals.

            The department consists of 3 dental clinics equpied with most recent and fully computerized dental units taking into consideration the American standards of sterilization and infection control.
            All dental units are supplied with fully digital x- ray machines which enable the clinician to early detect any abnormality with high precision.<br><br>
            Our dental laboratory is highly sophisticated and supplied with the latest machinery necessary to fabricate prosthetic restoration including dental implants, utilizing the highest quality materials.<br><br>

            Services provided by the department include: <br>
            1- Cosmetic dentistry which became area of inter est to most people nowadays, this include:<br>
            - Bleaching and whitening which avoids invasive crown work.<br>
            - Cosmetic, tooth colored fillings for both anterior and posterior teeth.<br>
            - Repair of broken and spaced anterior teeth.<br>

            2- Prosthetic dentistry, fixed and removable bridges as well as dental implants.<br>

            3- Pedodantic comprehensive painless dental treatment in one session.<br>

            4- Maxillofacial surgery for jaw trauma, tumours, congenital deformties, etc…<br>

            5- Orthodontic treatment and orthognathic surgery.<br>

        </p><br><br>




    </div>
</div>

<div class="col-md-12">
    <br><br>
</div>


<?php include"includes/footer.php" ?>
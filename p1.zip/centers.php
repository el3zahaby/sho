﻿<?php include"includes/header.php" ?>



<div class="col-md-3" style="padding-top:25px;">
    <div class="list-group">
        <a  class="list-group-item active ">Department & Centers </a>
        <a href="departments" class="list-group-item list-group-item-action">Departments</a>
        <a href="centers" class="list-group-item list-group-item-action">Centers</a>
    </div>
</div>

<div class="col-md-9" style="padding-top:25px;">
    No content

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <!--
<div class="row">

<div class="col-md-4">
<div class="card" style="height:100%">
<img class="img-responsive" src="files/images/news_001.jpg" alt="Card image cap">
<div class="card-body">
<a href="spcenters" class="list-group-item "><h4 class="card-title">Center...</h4></a>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card" style="height:100%">
<img class="img-responsive" src="files/images/news_002.jpg" alt="Card image cap" />
<div class="card-body">
<a href="spcenters" class="list-group-item ">	<h4 class="card-title">Center...</h4></a>
</div>
</div>
</div>

</div>
-->
</div>

<div class="col-md-12">
    <br><br>
</div>

<?php include"includes/footer.php" ?>